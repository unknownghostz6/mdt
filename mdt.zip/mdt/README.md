# ghost_mdt

## How to Install?

1. Run the user_mdt SQL in your database.
2. Inside sv_mdt you will be able to change the job required to use the mdt (default is police).
3. Make sure you ensure ghost_mdt on your resources list. Also disable any other mdt script you are using.